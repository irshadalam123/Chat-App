package com.example.messenger;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    EditText email, userName, userId, password;
    Button register_button;
    FirebaseAuth fAuth;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userName = findViewById(R.id.user_name);
        email = findViewById(R.id.email);
        userId = findViewById(R.id.user_id);
        password = findViewById(R.id.password);
        register_button = findViewById(R.id.register);
        progressBar = findViewById(R.id.progressBar2);

        fAuth = FirebaseAuth.getInstance();


        if (fAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
            finish();
        }

        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_email = email.getText().toString().trim();
                String user_pass = password.getText().toString().trim();
                String user_id = userId.getText().toString().trim();
                String user_name = userName.getText().toString().trim();

                if(TextUtils.isEmpty(user_name)){
                    userName.setError("Please Enter Your Name");
                    return;
                }
                if(TextUtils.isEmpty(user_id)){
                    userId.setError("Please Enter Your Id");
                    return;
                }
                if(TextUtils.isEmpty(user_email)){
                    email.setError("Please Enter Your Email");
                    return;
                }
                if(TextUtils.isEmpty(user_pass)){
                    password.setError("Please Enter Your Password");
                    return;
                }


                if(user_pass.length()<8){
                    password.setError("Password must be minimum 8 character");
                }

                progressBar.setVisibility(View.VISIBLE);

                fAuth.createUserWithEmailAndPassword(user_email, user_pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(getApplicationContext(),"Account created successfully..",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        }else{
                            Toast.makeText(getApplicationContext(),"Error! "+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

}
