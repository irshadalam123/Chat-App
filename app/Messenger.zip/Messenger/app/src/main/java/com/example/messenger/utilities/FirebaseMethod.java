package com.example.messenger.utilities;

import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class FirebaseMethod {

    FirebaseAuth mAuth;
    Context mcontext;

    public FirebaseMethod(Context context){
        mAuth = FirebaseAuth.getInstance();
        mcontext = context;
    }

    public void register_new_email(String strEmail, String strPass){

    }

}
